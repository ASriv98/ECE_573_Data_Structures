# ECE_573_Data_Structures
ECE 573 - Data Structures and Algorithms Graduate Course

Details for compilation: Python3(3.5.2) (default, Nov 12 2018, 14:36:49) 
[GCC 5.4.0 20160609] on linux2


TO RUN each problem:
run python main.py

see main.py in each problem if need to adjust any inputs/data

Make sure you have the following library installed:
https://github.com/peterhil/leftrb/tree/master/leftrb

